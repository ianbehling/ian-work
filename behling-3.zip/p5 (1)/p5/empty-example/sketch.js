function setup() {
  createCanvas(400, 400);
  frameRate(30)
}

let mx=10
  let my=10
  let mxp=0
  let myp=0
let sc =255
let sw=10
let bg=2
function draw() {
  background(bg);
  

  strokeWeight(sw)
  stroke(sc)
  point(mx,my)
  point(mx+200,my+200)
    point(mx+70,my+200)
    point(mx+180,my+300)
    point(mx+10,my+130)
  
  if(mx<400 && my<400){
  mx=mx+10 
  my=my+5}
  else{
 mx=mx-400
  my=my-200}
  
  while(bg<100){
bg=bg+20}
  
  if(keyIsPressed===true){
  sw=sw+1
  }else{sw=10}
}
function mouseClicked (){
if(sc===255){
  sc=1
  }
  else{sc=255}
  
}



