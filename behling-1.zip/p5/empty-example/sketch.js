function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(100);
  
  colorMode(RGB,255,255,255,1) 
  
noStroke()
  fill(200,0,0)
  ellipse(100,200,75,100)
  stroke(1)
  strokeWeight(3)
  point(100,250)
  point(110,300)
   point(90,350)
   point(100,400)
  
  noFill()
  beginShape()
  curveVertex(100,250)
  curveVertex(100,250)
   curveVertex(110,300)
   curveVertex(90,350)
   curveVertex(100,400)
     curveVertex(100,400)
  endShape()
  fill(0,100,170,)
  noStroke()
  beginShape()
  triangle(200,250,170,300,230,300)
endShape()
  stroke(1)
    noFill()
  beginShape()
  curveVertex(200,300)
  curveVertex(200,300)
   curveVertex(210,320)
   curveVertex(190,350)
   curveVertex(200,400)
     curveVertex(100,400)
endShape()
  translate(300,200)
  fill(0,150,120)
  noStroke()
  quad(50,50,20,55,0,100,40,80)
  stroke(1)
    noFill()
  beginShape()
  curveVertex(0,100)
  curveVertex(0,100)
   curveVertex(0,200)
   curveVertex(190,350)
   curveVertex(100,100)
     curveVertex(100,400)
  endShape()
  
  
}