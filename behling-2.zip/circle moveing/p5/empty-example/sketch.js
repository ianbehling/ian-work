function setup() {
  createCanvas(600, 400);
  let fr=10;
  
  frameRate(pow(fr,2));
}

function draw() {
  background(200);
  colorMode(RGB,255,255,255,1);
  let mx=mouseX;
  let my=mouseY;
  let pmy=pmouseY;
  let pmx=pmouseX;
  strokeWeight(5)
  fill(200,10,0,.5)
  stroke(0,70,100,.5)
  ellipse(mx,my,sqrt(pmx+10),sqrt(pmy+10));
  
}